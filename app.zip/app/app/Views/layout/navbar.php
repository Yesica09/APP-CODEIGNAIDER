<nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
  <a class="navbar-item" href="/">App</a>
    <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
    <div class="navbar-start">
      <a class="navbar-item" href="/news/">
        Noticias
      </a>
      <a class="navbar-item" href="/periodista/">
        Periodistas
      </a>
      <a class="navbar-item" href="/categoria/">
        Categorías
      </a>
      <a class="navbar-item" href="/staff/">
        Staff
      </a>
    </div>
  </div>
</nav>