<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="section">
    <form action="/periodista/create" method="post">
        <?= csrf_field() ?>

        <div class="field">
            <label class="label" for="">Nombre:</label>
            <div class="control">
                <input class="input" max=50 type="text" name="nombre" id="">
            </div>
        </div>
        <div class="field">
            <label class="label" for="">Apellidos:</label>
            <div class="control">
                <input class="input" max=50 type="text" name="apellidos" id="">
            </div>
        </div>
        <!-- Lista desplegable-->
        <div class="field">
            <label class="label" for="">Área:</label>
            <div class="select">
                <select name ="area" id="">
                    <option value="Politica">Politica</option>
                    <option value="Educacion">Educacion</option>
                    <option value="Cultura">Cultura</option>
                    <option value="Espectaculos">Espectaculos</option>
                    <option value="Deportes">Deportes</option>
                </select>
            </div>

        </div>
        <div class="field">
            <label class="label" for="">Acerca de mí:</label>
            <div class="control">
            <select name= "area
            
                <textarea class="textarea" name="bio" placeholder="Este soy yo ..."></textarea>                
            </div>
        </div>

        <div class="field">
            <label class="label" for="">Correo electronico:</label>
            <div class="control">
                <input class="input" max=100 type="email" name="email" id="">
            </div>
        </div>

        <div class="field">
            <label class="label" for="">telefono:</label>
            <div class="control">
                <input class="input" max=15 type="tel" name="telefono" id="">
            </div>
        </div>

       

        <div class="field is-grouped">
            <div class="control">
                <input type="submit" class="button is-link" value="Guardar">
            </div>
            <div class="control">
                <input type="reset" value="Restablecer" class="button is-link is-light">
            </div>
        </div>
    </form>
</div>

<?= $this->endSection() ?>