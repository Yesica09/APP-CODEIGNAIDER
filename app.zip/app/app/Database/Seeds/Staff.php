<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Staff extends Seeder
{
    public function run()
    {
        //
    }
}
